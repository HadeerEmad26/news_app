 import 'package:flutter/material.dart';

 const Color primaryColor = Colors.blue;
 const Color lightGreen = Color(0xFFDFECDB);
 const Color darkPrimaryColor = Color(0xFF141A2E);
 const Color yellowColor = Color(0xFFFACC1D);
 const Color blackColor = Color(0xFF242424);
