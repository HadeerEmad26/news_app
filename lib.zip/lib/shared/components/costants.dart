class Constants{

  static String API_KEY="ba6456480f5f43c08bcc997d43eb0873";
  static String BASE_URL="newsapi.org";
}